from fastapi import FastAPI
from pydantic import BaseModel
import requests, os, base64

app = FastAPI()

HF_API_KEY = os.getenv("HF_API_KEY")
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
GITHUB_USER = os.getenv("GITHUB_USER")  # Your GitHub username

class Prompt(BaseModel):
    idea: str

@app.post("/build")
def build_app(prompt: Prompt):
    headers = {"Authorization": f"Bearer {HF_API_KEY}"}
    ai_response = requests.post(
        "https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.2",
        headers=headers,
        json={"inputs": f"Build a full stack app for: {prompt.idea}. Return a dict with filenames and file contents."}
    ).json()
    return {"ai": ai_response}

@app.post("/deploy")
def deploy_to_github(prompt: Prompt):
    repo_name = prompt.idea.lower().replace(" ", "-")
    headers = {
        "Authorization": f"token {GITHUB_TOKEN}",
        "Accept": "application/vnd.github+json"
    }

    # Create GitHub repo
    repo = requests.post(
        "https://api.github.com/user/repos",
        headers=headers,
        json={"name": repo_name, "private": False}
    ).json()
    repo_url = repo.get("html_url")

    # Push files from AI build
    ai_build = requests.post(
        "http://localhost:8000/build",
        json={"idea": prompt.idea}
    ).json()

    for filename, content in ai_build["ai"].items():
        content_encoded = base64.b64encode(content.encode()).decode()
        requests.put(
            f"https://api.github.com/repos/{GITHUB_USER}/{repo_name}/contents/{filename}",
            headers=headers,
            json={"message": f"Add {filename}", "content": content_encoded}
        )

    return {"repo_url": repo_url, "status": "Deployed to GitHub. Trigger Vercel next."}